document.addEventListener('DOMContentLoaded', function() {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  document.getElementById('login-btn').style.display = isLoggedIn ? 'none' : 'inline';
  document.getElementById('signup-btn').style.display = isLoggedIn ? 'none' : 'inline';
  document.getElementById('logout-btn').style.display = isLoggedIn ? 'inline' : 'none';
  document.getElementById('payment-btn').style.display = isLoggedIn ? 'inline' : 'none';
  
  document.getElementById('logout-btn').addEventListener('click', function() {
    localStorage.removeItem('isLoggedIn');
    window.location.href = '/html/login.html';
  });

  loadMovies();          // 🎬 영화 리스트 불러오기
  loadReservationChart(); // 📈 차트 데이터 불러오기
});

// 🎬 영화 리스트 로드
function loadMovies() {
  fetch('/data/movies.json')
    .then(response => response.json())
    .then(data => {
      const container = document.getElementById('movies-container');
      data.movies.forEach(movie => {
        const div = document.createElement('div');
        div.className = 'movie-card';
        div.innerHTML = `
          <img src="${movie.image}" alt="${movie.title}">
          <h2>${movie.title}</h2>
          <p>${movie.description}</p>
          <button class="btn-reserve" data-title="${movie.title}">예매하기</button>
        `;
        container.appendChild(div);
      });

      setupReserveButtons(); // 🔥 영화 로드 후 버튼 이벤트 연결
    })
    .catch(err => console.error('영화 목록 로드 실패:', err));
}

// 📈 예매 누적 그래프 로드
function loadReservationChart() {
  fetch('/data/chart-data.json')
    .then(response => response.json())
    .then(chartData => {
      const ctx = document.getElementById('reservationChart').getContext('2d');

      const datasets = chartData.movies.map(movie => ({
        label: movie.title,
        data: movie.data,
        borderColor: movie.borderColor,
        backgroundColor: movie.backgroundColor,
        fill: true,
        tension: 0.3
      }));

      new Chart(ctx, {
        type: 'line',
        data: {
          labels: chartData.labels,
          datasets: datasets
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              display: true,
              position: 'top',
              labels: {
                usePointStyle: true
              }
            }
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '날짜'
              }
            },
            y: {
              title: {
                display: true,
                text: '누적 예매 수'
              },
              beginAtZero: true
            }
          }
        }
      });
    })
    .catch(err => console.error('차트 데이터 로드 실패:', err));
}

// 🔥 모달 열기
function openModal(contentHtml) {
  const modal = document.getElementById('modal-template');
  debugger
  const modalBody = modal.querySelector('.modal-body');
  modalBody.innerHTML = contentHtml;
  modal.classList.remove('hidden');

  const closeButton = document.getElementById('close-modal');
  closeButton.onclick = function() {
    modal.classList.add('hidden');
    modalBody.innerHTML = ''; // 닫으면 내용 비우기
  };
}

// 🔥 예매 버튼 클릭했을 때 모달 호출
function setupReserveButtons() {
  const reserveButtons = document.querySelectorAll('.btn-reserve');
  reserveButtons.forEach(button => {
    button.addEventListener('click', function() {
      const movieTitle = this.getAttribute('data-title');

      const formHtml = `
        <h2>영화 예매</h2>
        <form id="reservation-form" class="reservation-form">
          <div class="form-group">
            <label>영화 제목</label>
            <input type="text" value="${movieTitle}" readonly>
          </div>
          <div class="form-group">
            <label>날짜 선택</label>
            <input type="date" required>
          </div>
          <div class="form-group">
            <label>시간 선택</label>
            <select required>
              <option value="">시간을 선택하세요</option>
              <option value="10:00">10:00</option>
              <option value="13:00">13:00</option>
              <option value="16:00">16:00</option>
              <option value="19:00">19:00</option>
            </select>
          </div>
          <div class="form-group">
            <label>좌석 수</label>
            <input type="number" min="1" max="10" required>
          </div>
          <div class="form-group">
            <label>좌석 선택</label>
            <img src="/assets/images/seats.png" alt="좌석 이미지" class="seat-map">
          </div>
          <button type="submit" class="btn-primary">예매 완료</button>
        </form>
      `;

      openModal(formHtml);
    });
  });
}
