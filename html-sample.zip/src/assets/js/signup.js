document.getElementById('signup-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const newUsername = document.getElementById('new-username').value;
    if (newUsername) {
      localStorage.setItem('isLoggedIn', 'true');
      window.location.href = '/main.html';
    }
  });
  