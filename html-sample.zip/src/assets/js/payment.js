// assets/js/payment.js

export function requestCardPayment({ amount, merchantUid, buyerName, buyerEmail, buyerTel }) {
    if (!window.IMP) {
      alert('결제 모듈이 로드되지 않았습니다.');
      return;
    }
  
    const IMP = window.IMP;
    IMP.init('imp84871844'); // 🔥 본인의 아임포트 가맹점 식별코드 입력
    const response = await PortOne.requestPayment({
      // Store ID 설정
      storeId: "store-4ff4af41-85e3-4559-8eb8-0d08a2c6ceec",
      // 채널 키 설정
      channelKey: "channel-key-893597d6-e62d-410f-83f9-119f530b4b11",
      paymentId: `payment-${crypto.randomUUID()}`,
      orderName: "나이키 와플 트레이너 2 SD",
      totalAmount: 1000,
      currency: "CURRENCY_KRW",
      payMethod: "CARD",
    });
    IMP.request_pay({
      // pg: "inicis",      // KG이니시스 PG사 코드
      channelKey: "channel-key-a6bb08f2-9e8d-4d1a-a623-188c088c7b1b",
      pay_method: "card",      // 카드 결제
      merchant_uid: merchantUid, // 주문번호
      name: "상품명",          // 결제상품명
      amount: amount,          // 결제 금액
      buyer_email: buyerEmail,
      buyer_name: buyerName,
      buyer_tel: buyerTel,
      buyer_addr: "서울특별시 강남구", // (선택)
      buyer_postcode: "12345",       // (선택)
    }, function (rsp) {
      if (rsp.success) {
        console.log('결제 성공:', rsp);
        // TODO: 서버에 결제 완료 알림 보내기 (imp_uid, merchant_uid 전송)
      } else {
        console.error('결제 실패:', rsp.error_msg);
        alert('결제에 실패했습니다: ' + rsp.error_msg);
      }
    });
  }
  