import express from 'express';
import paymentController from '../controllers/paymentController.js';
import authMiddleware from '../middlewares/authMiddleware.js';

const router = express.Router();

/**
 * @swagger
 * /payments/payment-methods:
 *   post:
 *     summary: 결제 카드 등록
 *     description: 사용자의 결제 카드를 등록합니다.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               number:
 *                 type: string
 *                 description: 카드 번호
 *                 example: '1234567890123456'
 *               exp_month:
 *                 type: string
 *                 description: 카드 만료 월 (01~12)
 *                 example: '09'
 *               exp_year:
 *                 type: string
 *                 description: 카드 만료 연도 (4자리)
 *                 example: '2029'
 *               birth:
 *                 type: string
 *                 description: 카드 소유자 생년월일 (YYMMDD)
 *                 example: '900101'
 *               pwd_2digit:
 *                 type: string
 *                 description: 카드 비밀번호 앞 2자리
 *                 example: '12'
 *     responses:
 *       200:
 *         description: 카드 등록 성공
 */
router.post('/payment-methods', authMiddleware, paymentController.addPaymentMethod);

/**
 * @swagger
 * /payments/payments/charge:
 *   post:
 *     summary: 결제 요청
 *     description: 등록된 카드로 결제합니다.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               product_id:
 *                 type: number
 *                 description: 결제할 상품 ID
 *                 example: 1
 *     responses:
 *       200:
 *         description: 결제 성공
 */
router.post('/payments/charge', authMiddleware, paymentController.chargePayment);

export default router;
