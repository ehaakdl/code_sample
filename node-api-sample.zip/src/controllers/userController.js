import userService from '../services/userService.js';

const getProfile = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const user = await userService.getProfile(userId);
    res.json(user);
  } catch (err) {
    next(err);
  }
};

export default { getProfile };
