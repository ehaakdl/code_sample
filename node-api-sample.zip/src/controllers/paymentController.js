import Joi from 'joi';
import paymentService from '../services/paymentService.js';

// 카드 등록 요청 스키마
const addPaymentMethodSchema = Joi.object({
  number: Joi.string().required(),          // 카드번호
  exp_month: Joi.string().required(),          // 카드 유효기간 월 (MM)
  exp_year: Joi.string().required(),          // 카드 유효기간 연도 (YY)
  birth: Joi.string().required(),           // 생년월일 (YYMMDD)
  pwd_2digit: Joi.string().length(2).required()  // 비밀번호 앞 2자리
});

// 결제 요청 스키마
const chargePaymentSchema = Joi.object({
  product_id: Joi.number().required() // 결제할 상품 ID
});

const addPaymentMethod = async (req, res, next) => {
  const { error, value } = addPaymentMethodSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const userId = req.user.id;
    const result = await paymentService.addPaymentMethod(userId, value);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

const chargePayment = async (req, res, next) => {
  const { error, value } = chargePaymentSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const userId = req.user.id;
    const result = await paymentService.chargePayment(userId, value.product_id);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

export default { addPaymentMethod, chargePayment };
