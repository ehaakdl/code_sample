import { fetchAllProducts } from '../services/productService.js';

export const getProducts = async (req, res) => {
  try {
    const products = await fetchAllProducts();
    res.status(200).json({ success: true, data: products });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
  }
};
