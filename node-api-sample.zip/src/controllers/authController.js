import Joi from 'joi';
import authService from '../services/authService.js';

// 회원가입 요청 스키마
const registerSchema = Joi.object({
  name: Joi.string().required(),
  age: Joi.number().integer().required(),
  gender: Joi.string().valid('male', 'female', 'other').required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(4).required(),
  user_type: Joi.string().valid('admin', 'normal').default('normal')
});

// 로그인 요청 스키마
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required()
});

const register = async (req, res, next) => {
  const { error, value } = registerSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const result = await authService.register(value);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

const login = async (req, res, next) => {
  const { error, value } = loginSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const result = await authService.login(value);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

const logout = async (req, res, next) => {
  try {
    const userId = req.user.id;
    await authService.logout(userId);
    res.json({ message: 'Logout successful' });
  } catch (err) {
    next(err);
  }
};

export default { register, login, logout };
