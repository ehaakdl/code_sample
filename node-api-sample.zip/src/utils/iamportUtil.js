import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const IAMPORT_API_URL = 'https://api.iamport.kr';
let accessToken = null;

// 🔥 1. PortOne (아임포트) 액세스 토큰 발급
const getToken = async () => {
  const response = await axios.post(`${IAMPORT_API_URL}/users/getToken`, {
    imp_key: process.env.IAMPORT_API_KEY,
    imp_secret: process.env.IAMPORT_API_SECRET
  });
  accessToken = response.data.response.access_token;
};

// 🔥 2. 빌링키 발급 (카드 등록)
const createBillingKey = async (customerUid, cardInfo) => {
  if (!accessToken) await getToken();

  const expiryYear = String(cardInfo.exp_year);
  const expiry = `${expiryYear}-${String(cardInfo.exp_month).padStart(2, '0')}`;// 2029-12 형태

  const response = await axios.post(`${IAMPORT_API_URL}/subscribe/customers/${customerUid}`, {
    pg: 'inicis',
    card_number: cardInfo.number,
    expiry: expiry,
    birth: cardInfo.birth,
    // PG사에서 검사를 안하네 틀려도 빌링키 발급됨
    // 운영모드에서는 비인증 심사후에 카드인증없이 발급된다.
    // 테스트모드라서 가능한거임
    // cvc, password 이런 값들을 UI에서 받아서 처리해야함
    pwd_2digit: cardInfo.pwd_2digit,
  }, {
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });

  return response.data.response;
};

// 🔥 3. 빌링키로 즉시 결제
const chargePayment = async (customerUid, amount, merchantUid, productName) => {
  if (!accessToken) await getToken();

  const response = await axios.post(`${IAMPORT_API_URL}/subscribe/payments/again`, {
    customer_uid: customerUid,
    amount: amount,
    merchant_uid: merchantUid,
    name: productName,
  }, {
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });

  return response.data.response;
};


export default { createBillingKey, chargePayment };
