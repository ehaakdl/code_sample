import jwtUtil from '../utils/tokenUtil.js';
import userTokenModel from '../db/models/tokenModel.js';
import db from '../db/config/knex.js';

const extractToken = (req) => {
  return req.headers.authorization?.split(' ')[1];
};

const verifyAndAttachUser = (token, req) => {
  const decoded = jwtUtil.verifyAccessToken(token);
  req.user = { id: decoded.id };
  return decoded;
};

const isTokenExpiringSoon = (decoded) => {
  const currentTime = Math.floor(Date.now() / 1000);
  const expiresIn = decoded.exp - currentTime;
  return expiresIn < 5 * 60; // 5분(300초) 이하
};

const refreshTokens = async (userId, res) => {
  const trx = await db.transaction();

  try {
    await userTokenModel.deleteTokens(userId, trx);

    const { accessToken, refreshToken, accessTokenExpiresAt, refreshTokenExpiresAt } = jwtUtil.generateTokens(userId);

    await userTokenModel.saveTokens(
      userId,
      accessToken,
      refreshToken,
      accessTokenExpiresAt,
      refreshTokenExpiresAt,
      trx
    );

    await trx.commit();
    res.setHeader('x-access-token', accessToken);
  } catch (err) {
    await trx.rollback();
    console.error('Token refresh error:', err);
    throw new Error('Failed to refresh token');
  }
};

const authMiddleware = async (req, res, next) => {
  try {
    const token = extractToken(req);
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = verifyAndAttachUser(token, req);

    if (isTokenExpiringSoon(decoded)) {
      await refreshTokens(decoded.id, res);
    }

    next();
  } catch (err) {
    console.error('Authentication error:', err);
    return res.status(401).json({ message: err.message || 'Invalid token' });
  }
};

export default authMiddleware;
