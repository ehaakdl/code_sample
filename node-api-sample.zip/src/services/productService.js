import { getAllProducts } from '../db/models/productModel.js';
import { getActiveProductById } from '../db/models/productModel.js';

export const fetchAllProducts = async (trx = null) => {
  const products = trx ? await getAllProducts(trx) : await getAllProducts();
  return products;
};

export const fetchActiveProductById = async (productId, trx = null) => {
  const product = trx ? await getActiveProductById(productId, trx) : await getActiveProductById(productId);
  return product;
};

export default { fetchAllProducts, fetchActiveProductById };