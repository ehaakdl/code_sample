import userModel from '../db/models/userModel.js';
import tokenModel from '../db/models/tokenModel.js';
import jwtUtil from '../utils/tokenUtil.js';
import passwordUtil from '../utils/passwordUtil.js';
import db from '../db/config/knex.js';

const register = async (userData) => {
  const trx = await db.transaction(); // 🔥 트랜잭션 시작
  try {
    // 이메일 중복 체크
    const existingUser = await trx('users').where({ email: userData.email }).first();
    if (existingUser) {
      throw new Error('Email already exists');
    }

    // 비밀번호 해시
    const hashedPassword = await passwordUtil.hashPassword(userData.password);

    // 유저 생성
    const [userId] = await trx('users').insert({
      name: userData.name,
      age: userData.age,
      gender: userData.gender,
      email: userData.email,
      password: hashedPassword,
      user_type: userData.user_type
    });

    // 토큰 생성
    const { accessToken, refreshToken, accessTokenExpiresAt, refreshTokenExpiresAt } = jwtUtil.generateTokens(userId);

    await trx('user_tokens').insert({
      user_id: userId,
      access_token: accessToken,
      refresh_token: refreshToken,
      access_token_expires_at: accessTokenExpiresAt,
      refresh_token_expires_at: refreshTokenExpiresAt
    });

    await trx.commit(); // 🔥 트랜잭션 커밋

    return { id: userId, accessToken, refreshToken };
  } catch (err) {
    await trx.rollback(); // 🔥 트랜잭션 롤백
    throw err;
  }
};

const login = async ({ email, password }) => {
  const user = await db('users').where({ email }).first();
  if (!user || !(await passwordUtil.comparePassword(password, user.password))) {
    throw new Error('Invalid credentials');
  }

  const { accessToken, refreshToken, accessTokenExpiresAt, refreshTokenExpiresAt } = jwtUtil.generateTokens(user.id);

  await db('user_tokens').insert({
    user_id: user.id,
    access_token: accessToken,
    refresh_token: refreshToken,
    access_token_expires_at: accessTokenExpiresAt,
    refresh_token_expires_at: refreshTokenExpiresAt
  });

  return { accessToken, refreshToken };
};

const logout = async (userId) => {
  await db('user_tokens').where({ user_id: userId }).del();
};

export default { register, login, logout };
