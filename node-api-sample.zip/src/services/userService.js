import userModel from '../db/models/userModel.js';

const getProfile = async (userId) => {
  return await userModel.findById(userId);
};

export default { getProfile };
