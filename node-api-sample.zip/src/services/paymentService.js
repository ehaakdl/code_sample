import iamportUtil from '../utils/iamportUtil.js';
import paymentModel from '../db/models/paymentModel.js';
import productService from './productService.js'
import { v4 as uuidv4 } from 'uuid';
import db from '../db/config/knex.js';

const addPaymentMethod = async (userId, cardInfo) => {
  const customerUid = `customer_${userId}_${Date.now()}`;

  const billingInfo = await iamportUtil.createBillingKey(customerUid, cardInfo);

  await paymentModel.savePaymentMethod(userId, customerUid, billingInfo.card_name, billingInfo.card_number);

  return { message: 'Card registered successfully', customer_uid: customerUid };
};

const chargePayment = async (userId, product_id) => {
  const trx = await db.transaction(); // ✅ 트랜잭션 시작
  try {
    const customerUid = await paymentModel.getCustomerUid(userId, trx); // trx 넘기기
    if (!customerUid) throw new Error('No card registered');

    // 주문번호
    const merchantUid = `order_${uuidv4()}`;

    const product = await productService.fetchActiveProductById(product_id, trx); // trx 넘기기
    if (!product) throw new Error('Product not found');

    const amount = product.price;
    
    const payment = await iamportUtil.chargePayment(customerUid, amount, merchantUid, product.name);

    await paymentModel.savePaymentHistory(userId, amount, merchantUid, payment.imp_uid, 'paid', product.id, trx); // trx 넘기기

    
    // iamportUtil은 외부 호출이라 trx 연관 없음

    await trx.commit(); // ✅ 모든 작업 성공 시 커밋

    return { message: 'Payment successful', payment };

  } catch (error) {
    await trx.rollback(); // ✅ 에러 발생 시 롤백
    throw error;
  }
};

export default { addPaymentMethod, chargePayment };
