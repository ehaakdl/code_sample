import db from '../config/knex.js';

export const saveTokens = async (userId, accessToken, refreshToken, accessTokenExpiresAt, refreshTokenExpiresAt, trx = null) => {
  const query = db('user_tokens').insert({
    user_id: userId,
    access_token: accessToken,
    refresh_token: refreshToken,
    access_token_expires_at: accessTokenExpiresAt,
    refresh_token_expires_at: refreshTokenExpiresAt
  });

  if (trx) {
    await query.transacting(trx);
  } else {
    await query;
  }
};

export const deleteTokens = async (userId, trx = null) => {
  const query = db('user_tokens').where({ user_id: userId }).del();

  if (trx) {
    await query.transacting(trx);
  } else {
    await query;
  }
};

export default { saveTokens, deleteTokens };
