import db from '../config/knex.js';

export const findByEmail = async (email, trx = null) => {
  const query = db('users')
    .where({ email })
    .first();

  return trx ? await query.transacting(trx) : await query;
};

export const findById = async (id, trx = null) => {
  const query = db('users')
    .select('id', 'name', 'age', 'gender', 'email', 'user_type')
    .where({ id })
    .first();

  return trx ? await query.transacting(trx) : await query;
};

export const createUser = async ({ name, age, gender, email, password, user_type }, trx = null) => {
  const query = db('users').insert({
    name,
    age,
    gender,
    email,
    password,
    user_type
  });

  const [insertId] = trx ? await query.transacting(trx) : await query;
  return insertId;
};

export default { findByEmail, findById, createUser };
