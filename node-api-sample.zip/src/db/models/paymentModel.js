import db from '../config/knex.js';

const savePaymentMethod = async (userId, customerUid, cardName, maskedNumber, trx = null) => {
  const query = db('payment_methods').insert({
    user_id: userId,
    customer_uid: customerUid,
    card_name: cardName,
    card_number_masked: maskedNumber
  });

  if (trx) {
    await query.transacting(trx);
  } else {
    await query;
  }
};

const getCustomerUid = async (userId, trx = null) => {
  const query = db('payment_methods')
    .where({ user_id: userId })
    .first();

  const record = trx ? await query.transacting(trx) : await query;
  return record?.customer_uid;
};

const savePaymentHistory = async (userId, amount, merchantUid, impUid, status, productId, trx = null) => {
  const query = db('payments').insert({
    user_id: userId,
    amount,
    merchant_uid: merchantUid,
    imp_uid: impUid,
    status,
    paid_at: db.fn.now(),
    product_id: productId
  });

  if (trx) {
    await query.transacting(trx);
  } else {
    await query;
  }
};

export default { savePaymentMethod, getCustomerUid, savePaymentHistory };
