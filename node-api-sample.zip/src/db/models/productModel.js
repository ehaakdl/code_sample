import db from '../config/knex.js';

export const getAllProducts = async (trx = null) => {
  const query = db('products')
    .select('id', 'name', 'description', 'price', 'is_active', 'created_at', 'updated_at')
    .where({ is_active: true });

  const rows = trx ? await query.transacting(trx) : await query;
  return rows;
};

export const getActiveProductById = async (productId, trx = null) => {
  const query = db('products')
    .select('id', 'name', 'description', 'price')
    .where({ id: productId, is_active: true })
    .first();

  const product = trx ? await query.transacting(trx) : await query;
  return product;
};
