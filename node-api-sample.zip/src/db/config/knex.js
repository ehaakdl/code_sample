import knex from 'knex';
import dotenv from 'dotenv';

dotenv.config();

const db = knex({
  client: 'mysql2',
  connection: {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    connectTimeout: 10000, // 10초 이내 연결 실패 시 에러
  },
  pool: {
    min: 0,
    max: 10,
    acquireTimeoutMillis: 30000, // 커넥션 풀 acquire 대기 최대시간
    idleTimeoutMillis: 30000,    // idle timeout
    afterCreate: (conn, done) => {
      // 연결될 때마다 ping으로 health check
      conn.query('SELECT 1', (err) => {
        if (err) {
          console.error('Failed to ping database:', err);
          done(err, conn); // 연결 실패
        } else {
          done(null, conn); // 연결 성공
        }
      });
    },
  }
});

export default db;
