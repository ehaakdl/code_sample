import path from 'path';
import { fileURLToPath } from 'url'; // ESM에서 __dirname 대체
import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

// ESM 환경이라면 __dirname 수동으로 만들어야 함
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const swaggerDefinition = {
  openapi: '3.0.0',
  info: {
    title: 'API',
    version: '1.0.0',
    description: 'API 문서',
  },
  servers: [
    {
      url: 'http://localhost:3000/api',
      description: '개발 서버',
    },
  ],
  components: {    // ✅ 여기가 핵심
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',  // 선택 (JWT 쓰는 경우 권장)
      },
    },
  },
  security: [
    {
      bearerAuth: [],
    },
  ],
};

// 여기가 핵심
const options = {
  swaggerDefinition,
  apis: [path.join(__dirname, '../routes/*.js')], // 여러 경로 읽게 설정 가능
};

export const swaggerSpec = swaggerJSDoc(options);
export { swaggerUi };
