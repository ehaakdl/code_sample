import app from './src/app.js'; // import 사용, .js 확장자까지 써야 함

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
