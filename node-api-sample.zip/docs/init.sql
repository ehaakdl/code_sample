-- ==========================================
-- 데이터베이스 생성 (없으면 주석처리)
CREATE DATABASE IF NOT EXISTS myapp
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE myapp;
-- ==========================================

-- users 테이블 (회원 정보)
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '유저 고유 ID',
    name VARCHAR(100) NOT NULL COMMENT '이름',
    age INT COMMENT '나이',
    gender ENUM('male', 'female', 'other') COMMENT '성별 (남성, 여성, 기타)',
    email VARCHAR(255) NOT NULL UNIQUE COMMENT '이메일 (고유)',
    password VARCHAR(255) NOT NULL COMMENT '암호화된 비밀번호',
    user_type ENUM('admin', 'normal') DEFAULT 'normal' NOT NULL COMMENT '유저 유형 (admin=관리자, normal=일반 사용자)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '생성일',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일'
) COMMENT='회원 (유저) 테이블'
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- payment_methods 테이블 (카드 등록 정보)
CREATE TABLE payment_methods (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '카드 정보 고유 ID',
    user_id BIGINT NOT NULL COMMENT 'users 테이블의 유저 ID (FK)',
    customer_uid VARCHAR(255) NOT NULL COMMENT 'Iamport 빌링키 (고객 고유 ID)',
    card_name VARCHAR(100) COMMENT '카드사 이름 (ex. 신한카드)',
    card_number_masked VARCHAR(20) COMMENT '마스킹된 카드 번호 (ex. ****-****-****-4242)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '생성일',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일',
    UNIQUE KEY unique_user_customer (user_id, customer_uid),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) COMMENT='유저별 카드 등록 정보 테이블'
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- user_tokens 테이블 (JWT 토큰 관리)
CREATE TABLE user_tokens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT 'user_tokens 고유 ID',
    user_id BIGINT NOT NULL COMMENT 'users 테이블의 ID (회원 고유 식별자)',
    access_token TEXT NOT NULL COMMENT 'Access Token (짧은 수명)',
    refresh_token TEXT NOT NULL COMMENT 'Refresh Token (긴 수명)',
    access_token_expires_at DATETIME NOT NULL COMMENT 'Access Token 만료 일시',
    refresh_token_expires_at DATETIME NOT NULL COMMENT 'Refresh Token 만료 일시',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '레코드 생성 시각',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '레코드 수정 시각',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) COMMENT='회원별 발급된 JWT 토큰 기록 테이블'
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- products 테이블 (상품 관리)
CREATE TABLE products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '상품 고유 ID',
    name VARCHAR(255) NOT NULL COMMENT '상품 이름',
    description TEXT COMMENT '상품 설명',
    price INT NOT NULL COMMENT '상품 가격 (원화)',
    is_active BOOLEAN DEFAULT TRUE COMMENT '상품 판매 활성화 여부',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '상품 등록일',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '상품 수정일'
) COMMENT='상품 관리 테이블'
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;

-- payments 테이블 (결제 내역)
CREATE TABLE payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '결제 고유 ID',
    user_id BIGINT NOT NULL COMMENT 'users 테이블 유저 ID',
    amount INT NOT NULL COMMENT '결제 금액 (원)',
    product_id BIGINT NOT NULL COMMENT 'products 테이블 상품 ID',
    status ENUM('paid', 'failed') NOT NULL COMMENT '결제 상태',
    imp_uid VARCHAR(255) COMMENT 'Iamport 결제 고유 ID',
    merchant_uid VARCHAR(255) COMMENT '상점 주문 번호',
    paid_at TIMESTAMP NULL COMMENT '결제 완료일',
    failed_reason TEXT COMMENT '실패 이유 (실패한 경우)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '생성일',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일',
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) COMMENT='결제 내역 테이블'
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;




INSERT INTO products (name, description, price, is_active)
VALUES 
  ('Basic Plan', '가장 기본적인 상품입니다.', 10, TRUE),
  ('Premium Plan', '추가 혜택이 포함된 프리미엄 상품입니다.', 20, TRUE),
  ('Annual Plan', '1년 동안 사용할 수 있는 연간 상품입니다.', 30, TRUE);
